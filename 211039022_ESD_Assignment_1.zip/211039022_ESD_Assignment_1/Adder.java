import java.lang.*;
import java.util.*;

public class Adder{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the 1st Bit number");
		int a = sc.nextInt();
		System.out.println("Enter the 2nd Bit number");
		int b = sc.nextInt();
		System.out.println("Enter the the carry bit");
		int cin = sc.nextInt();

		int sum = a^b^cin;
		int cout = a&b|b&cin|cin&a;

		System.out.println("The Sum generated is : " + sum);
		System.out.println("The Carry generated is : " + cout);
	}
	
	}